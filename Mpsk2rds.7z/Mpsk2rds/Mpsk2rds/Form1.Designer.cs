﻿namespace Mpsk2rds
{
    partial class formMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.labelLocalhost = new System.Windows.Forms.Label();
            this.labelMultiPSKPort = new System.Windows.Forms.Label();
            this.numericUpDownMultiPSKport = new System.Windows.Forms.NumericUpDown();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.labelPI = new System.Windows.Forms.Label();
            this.textBoxPI = new System.Windows.Forms.TextBox();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMultiPSKport)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fleToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(498, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // fleToolStripMenuItem
            // 
            this.fleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fleToolStripMenuItem.Name = "fleToolStripMenuItem";
            this.fleToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fleToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHelpToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // viewHelpToolStripMenuItem
            // 
            this.viewHelpToolStripMenuItem.Name = "viewHelpToolStripMenuItem";
            this.viewHelpToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.viewHelpToolStripMenuItem.Text = "View Help";
            this.viewHelpToolStripMenuItem.Click += new System.EventHandler(this.viewHelpToolStripMenuItem_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(270, 38);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 5;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(358, 38);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 6;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // labelLocalhost
            // 
            this.labelLocalhost.AutoSize = true;
            this.labelLocalhost.Location = new System.Drawing.Point(12, 42);
            this.labelLocalhost.Name = "labelLocalhost";
            this.labelLocalhost.Size = new System.Drawing.Size(80, 13);
            this.labelLocalhost.TabIndex = 0;
            this.labelLocalhost.Text = "Host: 127.0.0.1";
            // 
            // labelMultiPSKPort
            // 
            this.labelMultiPSKPort.AutoSize = true;
            this.labelMultiPSKPort.Location = new System.Drawing.Point(102, 42);
            this.labelMultiPSKPort.Name = "labelMultiPSKPort";
            this.labelMultiPSKPort.Size = new System.Drawing.Size(71, 13);
            this.labelMultiPSKPort.TabIndex = 1;
            this.labelMultiPSKPort.Text = "MultiPSK port";
            // 
            // numericUpDownMultiPSKport
            // 
            this.numericUpDownMultiPSKport.Location = new System.Drawing.Point(186, 40);
            this.numericUpDownMultiPSKport.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.numericUpDownMultiPSKport.Name = "numericUpDownMultiPSKport";
            this.numericUpDownMultiPSKport.Size = new System.Drawing.Size(66, 20);
            this.numericUpDownMultiPSKport.TabIndex = 2;
            this.numericUpDownMultiPSKport.Value = new decimal(new int[] {
            3122,
            0,
            0,
            0});
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "spy";
            this.saveFileDialog1.Filter = "\"Rds spy files|*.spy|All files|*.*\"";
            // 
            // labelPI
            // 
            this.labelPI.AutoSize = true;
            this.labelPI.Location = new System.Drawing.Point(129, 72);
            this.labelPI.Name = "labelPI";
            this.labelPI.Size = new System.Drawing.Size(44, 13);
            this.labelPI.TabIndex = 9;
            this.labelPI.Text = "PI code";
            // 
            // textBoxPI
            // 
            this.textBoxPI.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxPI.Location = new System.Drawing.Point(186, 69);
            this.textBoxPI.MaxLength = 4;
            this.textBoxPI.Name = "textBoxPI";
            this.textBoxPI.Size = new System.Drawing.Size(51, 20);
            this.textBoxPI.TabIndex = 10;
            this.textBoxPI.Text = "0000";
            // 
            // formMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 155);
            this.Controls.Add(this.textBoxPI);
            this.Controls.Add(this.labelPI);
            this.Controls.Add(this.numericUpDownMultiPSKport);
            this.Controls.Add(this.labelMultiPSKPort);
            this.Controls.Add(this.labelLocalhost);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "formMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MultiPSK2RdsSpy";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formMain_FormClosing);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMultiPSKport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Label labelLocalhost;
        private System.Windows.Forms.Label labelMultiPSKPort;
        private System.Windows.Forms.NumericUpDown numericUpDownMultiPSKport;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label labelPI;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHelpToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxPI;
    }
}

