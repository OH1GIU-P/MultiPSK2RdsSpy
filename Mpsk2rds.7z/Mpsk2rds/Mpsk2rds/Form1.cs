﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Sockets;
using System.Net;

namespace Mpsk2rds
{
    public partial class formMain : Form
    {
        const string IP_ADDR = "127.0.0.1";
        const int SCK_BUF_SIZE = 256;
        const int SERVER_READ_TIMEOUT = 6000;
        const int DO_EVENTS = 8;
        const string DEF_A_BLOCK = "0000";
        const char RB = 'B';
        const char RC = 'C';
        const char RD = 'D';
        const char RQ = '=';
        bool bFetch = false;

        public formMain()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            bFetch = false;
            saveFileDialog1.FileName = "";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            {
                if (textBoxPI.Text.Length != 4)
                {
                    textBoxPI.Text = DEF_A_BLOCK;
                }
                buttonStart.Enabled = false;
                buttonStop.Enabled = true;
                numericUpDownMultiPSKport.Enabled = false;
                textBoxPI.Enabled = false;
                StringBuilder sb = new StringBuilder();
                try
                {
                    TcpClient tcpclient = new TcpClient(IP_ADDR, Convert.ToInt32(numericUpDownMultiPSKport.Value));
                    NetworkStream serverStream = tcpclient.GetStream();
                    serverStream.ReadTimeout = SERVER_READ_TIMEOUT;

                    int d = 0;
                    int datacnt = 0;
                    byte[] datareceived = new byte[SCK_BUF_SIZE];
                    bFetch = true;

                    while ((datacnt = serverStream.Read(datareceived, 0, SCK_BUF_SIZE)) > 0)
                    {
                        sb.Append(Encoding.ASCII.GetString(datareceived, 0, datacnt));
                        if (!bFetch)
                        {
                            break;
                        }
                        d++;
                        if (d == DO_EVENTS)
                        {
                            d = 0;
                            Application.DoEvents();
                        }
                    }
                    tcpclient.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                string rds_blocks = sb.ToString();
                if (rds_blocks != "")
                {
                    StreamWriter rds = new StreamWriter(saveFileDialog1.FileName, false, Encoding.ASCII);
                    string blockA = textBoxPI.Text;
                    string blockB = "";
                    string blockC = "";
                    string blockD = "";
                    int n = 0;
                    int l = rds_blocks.Length - 1;
                    sb.Clear();

                    for (n = 1; n < l; n +=2)
                    {
                        sb.Append(rds_blocks[n]);
                    }
                    rds_blocks = sb.ToString();

                    l = rds_blocks.Length - 1;
                    for (n = 0; n < l; n++)
                    {
                        try
                        {
                            if (rds_blocks[n] == RB && rds_blocks[n + 1] == RQ)
                            {
                                blockB = rds_blocks.Substring(n + 2, 4);
                            }
                        }
                        catch (Exception)
                        {
                            blockB = "";
                        }
                        try
                        {
                            if (rds_blocks[n] == RC && rds_blocks[n + 1] == RQ)
                            {
                                blockC = rds_blocks.Substring(n + 2, 4);
                            }
                        }
                        catch (Exception)
                        {
                            blockC = "";
                        }
                        try
                        {
                            if (rds_blocks[n] == RD && rds_blocks[n + 1] == RQ)
                            {
                                blockD = rds_blocks.Substring(n + 2, 4);
                            }
                        }
                        catch (Exception)
                        {
                            blockD = "";
                        }
                        if (blockB != "" && blockC != "" && blockD != "")
                        {
                            rds.WriteLine(blockA + blockB + blockC + blockD);
                            blockB = "";
                            blockC = "";
                            blockD = "";
                        }
                    }
                    rds.Close();
                }
                buttonStart.Enabled = true;
                buttonStop.Enabled = false;
                textBoxPI.Enabled = true;
                numericUpDownMultiPSKport.Enabled = true;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            bFetch = false;
        }

        private void viewHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MultiPSK RDS decoded blocks to RDS Spy *.spy file format\r\n\r\nAt first start MultiPSK RDS & decoded blocks and then start MultiPSK TCP/IP link.\r\nSet same TCP port in MultiPSK & this app. Press Start and select file to save data.");
        }

        private void formMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            bFetch = false;
            if (!buttonStart.Enabled)
            {
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }
    }
}
